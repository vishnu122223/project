def get_grade(marks):
    if 90 <= marks <= 100:
        return 'A'
    elif 80 <= marks < 90:
        return 'B'
    elif 70 <= marks < 80:
        return 'C'
    elif 60 <= marks < 70:
        return 'D'
    elif 0 <= marks < 60:
        return 'F'
    else:
        return 'Invalid'

def main():
    # Input student details
    student_name = input("Enter the student's name: ")
    student_class = input("Enter the student's class: ")
    try:
        student_marks = float(input("Enter the student's marks (0-100): "))
        # Validate marks
        if 0 <= student_marks <= 100:
            # Calculate grade
            student_grade = get_grade(student_marks)
            # Output
            print(f"\nStudent Name: {student_name}")
            print(f"Class: {student_class}")
            print(f"Marks: {student_marks}")
            print(f"Grade: {student_grade}")
        else:
            print("Marks should be between 0 and 100.")
    except ValueError:
        print("Please enter a valid number for marks.")

if _name_ == "_main_":
    main()
